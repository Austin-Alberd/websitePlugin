//code for the event handling portions
//code for anyother stuf :)
// code for the mental health portion 
var Q1 = null;
var Q2= null;
var Q3= null;
var Q4= null;
var Q5= null;
var mental= [null,null,null,null,null];
var mentalHealthScore = mental[0]+mental[1]+mental[2]+mental[3]+mental[4];
// code for the physical health portion
var Q6= null;
var Q7= null;
var Q8= null;
var Q9= null;
var Q10= null;
var physical = [null,null,null,null,null];
var physicalHealthScore = physical[0]+physical[1]+physical[2]+physical[3]+physical[4];
// code for the dietairy heath portion
var Q11= null;
var Q12= null;
var Q13= null;
var Q14= null;
var Q15= null;
var dietairy = [null,null,null,null,null];
var dietairyHealthScore = dietairy[0]+dietairy[1]+dietariy[2]+dietairy[3]+dietairy[4];
// code for calcultaing the final score
var scoreSeries = [null,null,null]
